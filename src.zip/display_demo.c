/* ------------------------------------------------------------ */
/*				Include File Definitions						*/
/* ------------------------------------------------------------ */

#include "display_demo.h"
#include "display_ctrl/display_ctrl.h"
#include <stdio.h>
#include "math.h"
#include <ctype.h>
#include <stdlib.h>
#include "xil_types.h"
#include "xil_cache.h"
#include "xparameters.h"
#include "xiicps.h"
#include "vdma.h"
#include "i2c/PS_i2c.h"
#include "xgpio.h"
#include "sleep.h"
#include "ov5640.h"
#include "xscugic.h"
#include "zynq_interrupt.h"
#include "xgpiops.h"
#include "ff.h"
#include "bmp.h"
#include "xil_cache.h"
#include "xtime_l.h"
/*
 * XPAR redefines
 */
#define DYNCLK_BASEADDR XPAR_AXI_DYNCLK_0_BASEADDR

#define VGA_VDMA_ID0 XPAR_AXIVDMA_3_DEVICE_ID
#define VGA_VDMA_ID1 XPAR_AXIVDMA_2_DEVICE_ID
#define VGA_VDMA_ID2 XPAR_AXIVDMA_5_DEVICE_ID
#define VGA_VDMA_ID3 XPAR_AXIVDMA_7_DEVICE_ID

#define DISP_VTC_ID XPAR_VTC_0_DEVICE_ID


#define KEY_INTR_ID        XPAR_XGPIOPS_0_INTR
#define MIO_0_ID           XPAR_PS7_GPIO_0_DEVICE_ID
#define GPIO_INPUT         0
#define GPIO_OUTPUT		   1
/* ------------------------------------------------------------ */
/*				Global Variables								*/
/* ------------------------------------------------------------ */

/*
 * Display Driver structs
 */
DisplayCtrl dispCtrl;


//XAxiVdma vdma_vout;
XIicPs ps_i2c0;
XIicPs ps_i2c1;
XGpio cmos_rstn;
XScuGic XScuGicInstance;
XAxiVdma vdma_vin[3]; //дvdmaΪ4����DISPLAY_NUM_VDMAҲҪ�ĳ�4
XAxiVdma hdvdma[1];

XAxiVdma *vdma[DISPLAY_NUM_VDMA];
u32 stride[DISPLAY_NUM_VDMA];


static int WriteError;

int wr_index[2]={0,0};
int rd_index[2]={0,0};
int frame_length_curr;

XGpioPs GpioInstance ;
extern volatile int key_flag ;
extern int KeyFlagHold  ;


extern volatile int key_flag1 ;
extern int KeyFlagHold1  ;

u8 frameBuf[DISPLAY_NUM_VDMA][DISPLAY_NUM_FRAMES][DEMO_MAX_FRAME] __attribute__ ((aligned(8))) ;
u8 *pFrames[DISPLAY_NUM_VDMA][DISPLAY_NUM_FRAMES];     //array of pointers to the frame buffers
/*
 * Framebuffers for video data
 */
u8 frameBuf0[DISPLAY_NUM_FRAMES][DEMO_MAX_FRAME] __attribute__ ((aligned(64)));
u8 frameBuf1[DISPLAY_NUM_FRAMES][DEMO_MAX_FRAME] __attribute__ ((aligned(64)));
u8 *pFrames0[DISPLAY_NUM_FRAMES]; //array of pointers to the frame buffers
u8 *pFrames1[DISPLAY_NUM_FRAMES];

u8 DframeBuf0[DISPLAY_NUM_FRAMES][DEMO_MAX_FRAME] __attribute__ ((aligned(64)));
u8 DframeBuf1[DISPLAY_NUM_FRAMES][DEMO_MAX_FRAME] __attribute__ ((aligned(64)));
//u8 *pFrames[DISPLAY_NUM_FRAMES];
extern u8 *DpFrames0[DISPLAY_NUM_FRAMES]; //array of pointers to the frame buffers
extern u8 *DpFrames1[DISPLAY_NUM_FRAMES];

 //hdmi vdma
u8 frameBuf2[DISPLAY_NUM_FRAMES][DEMO_MAX_FRAME] __attribute__ ((aligned(64)));
u8 frameBuf3[DISPLAY_NUM_FRAMES][DEMO_MAX_FRAME] __attribute__ ((aligned(64)));
u8 *hdFrames2[DISPLAY_NUM_FRAMES]; //array of pointers to the frame buffers
u8 *hdFrames3[DISPLAY_NUM_FRAMES];

int WriteOneFrameEnd[2]={-1,-1};
u8 photobuf[DEMO_MAX_FRAME] ;
unsigned char PhotoBuf[DEMO_MAX_FRAME] ;

/* ------------------------------------------------------------ */
/*				Procedure Definitions							*/
/* ------------------------------------------------------------ */
static void WriteCallBack0(void *CallbackRef, u32 Mask);
static void WriteCallBack1(void *CallbackRef, u32 Mask);
static void WriteErrorCallBack(void *CallbackRef, u32 Mask);


void GpioHandler(void *CallbackRef);
int GpioSetup(XScuGic *InstancePtr, u16 DeviceId, u16 IntrID, XGpioPs *GpioInstancePtr) ;
int GpioSetup1(XScuGic *InstancePtr, u16 DeviceId, u16 IntrID, XGpioPs *GpioInstancePtr) ;


void resetVideoFmt(int w, int h, int ch)                                            //��λvdma���жϡ��Ĳ���
{

	frame_length_curr = 0;
	/* Stop vdma write process, disable vdma interrupt */                           //ֹͣ vdma���ر��жϣ�
	vdma_write_stop(&vdma_vin[ch]);
	XAxiVdma_IntrDisable(&vdma_vin[ch], XAXIVDMA_IXR_ALL_MASK, XAXIVDMA_WRITE);

	/* reconfig Sensor horizontal width and vertical height */                      //���� w,h,ch ��ֵ�������� sensor �ķֱ���
	if(ch == 0)
	{
		i2c_reg16_write(&ps_i2c0, 0x3c, 0x3808, (w>>8)&0xff);
		i2c_reg16_write(&ps_i2c0, 0x3c, 0x3809, (w>>0)&0xff);
		i2c_reg16_write(&ps_i2c0, 0x3c, 0x380a, (h>>8)&0xff);
		i2c_reg16_write(&ps_i2c0, 0x3c, 0x380b, (h>>0)&0xff);
	}
	else
	{
		i2c_reg16_write(&ps_i2c1, 0x3c, 0x3808, (w>>8)&0xff);
		i2c_reg16_write(&ps_i2c1, 0x3c, 0x3809, (w>>0)&0xff);
		i2c_reg16_write(&ps_i2c1, 0x3c, 0x380a, (h>>8)&0xff);
		i2c_reg16_write(&ps_i2c1, 0x3c, 0x380b, (h>>0)&0xff);
	}

	/*
	 * Initial vdma write path, set call back function and register interrupt to GIC   //��ʼ�� vdma дͨ������ pFrame �����������ַд�� S2MM StartAddresses �Ĵ���������xAxiVdma_SetCallBack �������ûص�������WriteCallBack �� WriteErrorCallBack
	 */
	if(ch == 0)
	{
		vdma_write_init(XPAR_AXIVDMA_1_DEVICE_ID, &vdma_vin[ch], w * 3, h, w * 3,     //�� pFrame �����������ַд�� S2MM StartAddresses �Ĵ���
				(unsigned int)pFrames0[0], (unsigned int)pFrames0[1], (unsigned int)pFrames0[2]);
		XAxiVdma_SetCallBack(&vdma_vin[ch], XAXIVDMA_HANDLER_GENERAL,WriteCallBack0, (void *)&vdma_vin[ch], XAXIVDMA_WRITE);      //����2���ص�����
		XAxiVdma_SetCallBack(&vdma_vin[ch], XAXIVDMA_HANDLER_ERROR,WriteErrorCallBack, (void *)&vdma_vin[ch], XAXIVDMA_WRITE);
		InterruptConnect(&XScuGicInstance,XPAR_FABRIC_AXI_VDMA_1_S2MM_INTROUT_INTR,XAxiVdma_WriteIntrHandler,(void *)&vdma_vin[ch]);

	}
	else
	{
		vdma_write_init(XPAR_AXIVDMA_0_DEVICE_ID, &vdma_vin[ch], w * 3, h, w * 3,
				(unsigned int)pFrames1[0], (unsigned int)pFrames1[1], (unsigned int)pFrames1[2]);
		XAxiVdma_SetCallBack(&vdma_vin[ch], XAXIVDMA_HANDLER_GENERAL,WriteCallBack1, (void *)&vdma_vin[ch], XAXIVDMA_WRITE);
		XAxiVdma_SetCallBack(&vdma_vin[ch], XAXIVDMA_HANDLER_ERROR,WriteErrorCallBack, (void *)&vdma_vin[ch], XAXIVDMA_WRITE);
		InterruptConnect(&XScuGicInstance,XPAR_FABRIC_AXI_VDMA_0_S2MM_INTROUT_INTR,XAxiVdma_WriteIntrHandler,(void *)&vdma_vin[ch]);

	}
	/* Start vdma write process, enable vdma interrupt */            //����vdma�������ж�
	XAxiVdma_IntrEnable(&vdma_vin[ch], XAXIVDMA_IXR_ALL_MASK, XAXIVDMA_WRITE);
	vdma_write_start(&vdma_vin[ch]);
	frame_length_curr = w*h*3;
}

int lwip_loop();


int main(void)
{

	int Status;
	int i,j;
	XAxiVdma_Config *vdmaConfig;
	XAxiVdma vmda0, vmda1, vmda2, vmda3;

	vdma[0] = &vmda0;
	vdma[1] = &vmda1;
	vdma[2] = &vmda2;                           //��vdma
	vdma[3] = &vmda3;

	//display frames
	InterruptInit(XPAR_SCUGIC_0_DEVICE_ID,&XScuGicInstance);
	//InterruptInit(XPAR_XSCUTIMER_0_DEVICE_ID,&XScuGicInstance);
	i2c_init(&ps_i2c0, XPAR_XIICPS_0_DEVICE_ID,100000);
	i2c_init(&ps_i2c1, XPAR_XIICPS_1_DEVICE_ID,100000);

	XGpio_Initialize(&cmos_rstn, XPAR_CMOS_RST_DEVICE_ID);   //initialize GPIO IP
	XGpio_SetDataDirection(&cmos_rstn, 1, 0x0);            //set GPIO as output
	XGpio_DiscreteWrite(&cmos_rstn, 1, 0x3);
	usleep(500000);
	XGpio_DiscreteWrite(&cmos_rstn, 1, 0x0);               //set GPIO output value to 0
	usleep(500000);
	XGpio_DiscreteWrite(&cmos_rstn, 1, 0x3);
	usleep(500000);


	sensor_init(&ps_i2c0);
	sensor_init(&ps_i2c1);
	for (i = 0; i < DISPLAY_NUM_VDMA; i++) {
		for (j = 0; j < DISPLAY_NUM_FRAMES; j++) {
			pFrames[i][j] = frameBuf[i][j];
			memset(pFrames[i][j], 0, DEMO_MAX_FRAME);
			Xil_DCacheFlushRange((INTPTR) pFrames[i][j], DEMO_MAX_FRAME) ;
		}
	}

	//camera vdma
	for (i = 0; i < DISPLAY_NUM_FRAMES; i++)
		{
			pFrames0[i] = frameBuf0[i];                                  //pFrame0ָ������ͷ 1 �Ļ���
			pFrames1[i] = frameBuf1[i];                                  //pFrame1ָ������ͷ 2 �Ļ���
			memset(pFrames0[i], 0, DEMO_MAX_FRAME);
			Xil_DCacheFlushRange((INTPTR) pFrames0[i], DEMO_MAX_FRAME) ;
			memset(pFrames1[i], 0, DEMO_MAX_FRAME);                      //�ѻ�����������
			Xil_DCacheFlushRange((INTPTR) pFrames1[i], DEMO_MAX_FRAME) ; //����������ˢ����DDR

		}

	//display vdma
	for (i = 0; i < DISPLAY_NUM_FRAMES; i++)
		{

			DpFrames0[i] = DframeBuf0[i];                                  //pFrame0ָ������ͷ 1 �Ļ���
			DpFrames1[i] = DframeBuf1[i];                                  //pFrame1ָ������ͷ 2 �Ļ���
			memset(DpFrames0[i], 0, DEMO_MAX_FRAME);
			Xil_DCacheFlushRange((INTPTR) DpFrames0[i], DEMO_MAX_FRAME) ;
			memset(DpFrames1[i], 0, DEMO_MAX_FRAME);                      //�ѻ�����������
			Xil_DCacheFlushRange((INTPTR) DpFrames1[i], DEMO_MAX_FRAME) ; //����������ˢ����DDR

		}

	//hdmi vdma
	for (i = 0; i < DISPLAY_NUM_FRAMES; i++)
		{
			hdFrames2[i] = frameBuf2[i];                                  //pFrame0ָ������ͷ 1 �Ļ���
			hdFrames3[i] = frameBuf3[i];                                  //pFrame1ָ������ͷ 2 �Ļ���
			memset(hdFrames2[i], 0, DEMO_MAX_FRAME);
			Xil_DCacheFlushRange((INTPTR) hdFrames2[i], DEMO_MAX_FRAME) ;
			memset(hdFrames3[i], 0, DEMO_MAX_FRAME);                      //�ѻ�����������
			Xil_DCacheFlushRange((INTPTR) hdFrames3[i], DEMO_MAX_FRAME) ; //����������ˢ����DDR

		}


		/*
		 * Initialize VDMA driver
		 */

		vdmaConfig = XAxiVdma_LookupConfig(VGA_VDMA_ID0);
				if (!vdmaConfig) {
					xil_printf("No video DMA found for ID %d\r\n", VGA_VDMA_ID0);

		}
				Status = XAxiVdma_CfgInitialize(vdma[0], vdmaConfig,
						vdmaConfig->BaseAddress);
				if (Status != XST_SUCCESS) {
					xil_printf("VDMA Configuration Initialization failed %d\r\n", Status);

				}


		vdmaConfig = XAxiVdma_LookupConfig(VGA_VDMA_ID1);
		if (!vdmaConfig) {
			xil_printf("No video DMA found for ID %d\r\n",VGA_VDMA_ID1);

				}
				Status = XAxiVdma_CfgInitialize(vdma[1], vdmaConfig,
						vdmaConfig->BaseAddress);
				if (Status != XST_SUCCESS) {
					xil_printf("VDMA Configuration Initialization failed %d\r\n", Status);

				}



		vdmaConfig = XAxiVdma_LookupConfig(VGA_VDMA_ID2);
				if (!vdmaConfig) {
					xil_printf("No video DMA found for ID %d\r\n", VGA_VDMA_ID2);
		}

				Status = XAxiVdma_CfgInitialize(vdma[2], vdmaConfig,
						vdmaConfig->BaseAddress);
				if (Status != XST_SUCCESS) {
					xil_printf("VDMA Configuration Initialization failed %d\r\n", Status);

				}



		vdmaConfig = XAxiVdma_LookupConfig(VGA_VDMA_ID3);
				if (!vdmaConfig) {
					xil_printf("No video DMA found for ID %d\r\n", VGA_VDMA_ID3);

		}

				Status = XAxiVdma_CfgInitialize(vdma[3], vdmaConfig,
						vdmaConfig->BaseAddress);
				if (Status != XST_SUCCESS) {
					xil_printf("VDMA Configuration Initialization failed %d\r\n", Status);

				}



				stride[0] = 1920 * 3;
				stride[1] = 1920 * 3;
				stride[2] = 1920 * 3;
		    	stride[3] = 1920 * 3;



	    Status = DisplayInitialize(&dispCtrl, vdma, DISP_VTC_ID, DYNCLK_BASEADDR,DpFrames0,DpFrames1,hdFrames2,hdFrames3,stride);
				if (Status != XST_SUCCESS)
				{
					xil_printf("Display Ctrl initialization failed during demo initialization%d\r\n",Status);
		        }




		dispCtrl.HoriSizeInput[0] = 800 * 3;
		dispCtrl.VertSizeInput[0] = 600;
		dispCtrl.HoriSizeInput[1] = 800 * 3;
		dispCtrl.VertSizeInput[1] = 600;

		dispCtrl.HoriSizeInput[2] = 800 * 3;
		dispCtrl.VertSizeInput[2] = 600;
		dispCtrl.HoriSizeInput[3] = 800 * 3;
		dispCtrl.VertSizeInput[3] = 600;

		Status = DisplayStart(&dispCtrl);
		if (Status != XST_SUCCESS)
		{
			xil_printf("Couldn't start display during demo initialization%d\r\n",Status);
		}


	GpioSetup(&XScuGicInstance, MIO_0_ID, KEY_INTR_ID, &GpioInstance) ;
	GpioSetup1(&XScuGicInstance, MIO_0_ID, KEY_INTR_ID, &GpioInstance) ;
    /*
	 * Interrupt initialization                                      //�жϳ�ʼ��
	 */
	        resetVideoFmt(800, 600, 0);
			resetVideoFmt(800, 600, 1);

	/* Start hdmi дVdma */

//		vdma_write_init(XPAR_AXIVDMA_4_DEVICE_ID, &hdvdma[0], 1280 * 3, 720, 1280 * 3,
//						(unsigned int)hdFrames2[0], (unsigned int)hdFrames2[1], (unsigned int)hdFrames2[2]);
//		vdma_write_init(XPAR_AXIVDMA_6_DEVICE_ID, &hdvdma[1], 1280 * 3, 720, 1280 * 3,
//								(unsigned int)hdFrames3[0], (unsigned int)hdFrames3[1], (unsigned int)hdFrames3[2]);
	//	vdma_write_init1(XPAR_AXIVDMA_4_DEVICE_ID, 1280 * 3, 720, 1920 * 3,(unsigned int)hdFrames2[0]);
	//	vdma_write_init1(XPAR_AXIVDMA_6_DEVICE_ID, 1280 * 3, 720, 1920 * 3,(unsigned int)hdFrames3[0]);

			vdma_write_init2(XPAR_AXIVDMA_4_DEVICE_ID, vdma[2], 800 * 3, 600, DEMO_STRIDE,	(unsigned int)hdFrames2[0], DISPLAY_NUM_FRAMES);
			vdma_write_init2(XPAR_AXIVDMA_6_DEVICE_ID, vdma[3], 800 * 3, 600, DEMO_STRIDE,	(unsigned int)hdFrames3[0], DISPLAY_NUM_FRAMES);
/*
			vdma_write_init(XPAR_AXIVDMA_4_DEVICE_ID, &vdma_vin[2], 1280 * 3, 720, 1280 * 3,
							(unsigned int)hdFrames2[0], (unsigned int)hdFrames2[1], (unsigned int)hdFrames2[2]);
			vdma_write_init(XPAR_AXIVDMA_6_DEVICE_ID, &vdma_vin[3], 1280 * 3, 720, 1280 * 3,
										(unsigned int)hdFrames3[0], (unsigned int)hdFrames3[1], (unsigned int)hdFrames3[2]);
			vdma_write_start(&vdma_vin[2]);
			vdma_write_start(&vdma_vin[3]);*/
	/*
	 * Start lwip engine
	 */
			//DemoPrintTest(DpFrames1[0],1280,720,DEMO_STRIDE,DEMO_PATTERN_1);
			lwip_loop();
	return 0;
}

/*****************************************************************************/
/*
 * Call back function for write channel
 *
 * This callback only clears the interrupts and updates the transfer status.         //�˻ص�������жϲ����´���״̬
 *
 * @param	CallbackRef is the call back reference pointer
 * @param	Mask is the interrupt mask passed in from the driver
 *
 * @return	None
 *
 ******************************************************************************/

void DemoPrintTest(u8 *frame, u32 width, u32 height, u32 stride, int pattern)
{
	u32 xcoi, ycoi;
	u32 iPixelAddr = 0;
	u8 wRed, wBlue, wGreen;
	u32 xInt;
	u32 pic_number=0;
	u32 BYTES_PIXEL=3;


	switch (pattern)
	{

	case DEMO_PATTERN_1:         //Grid

		for(ycoi = 0; ycoi < height; ycoi++)
		{
			for(xcoi = 0; xcoi < (width * BYTES_PIXEL); xcoi+=BYTES_PIXEL)
			{
				if (((xcoi/BYTES_PIXEL)&0x20)^(ycoi&0x20)) {
					wRed = 255;
					wGreen = 255;
					wBlue = 255;
				}
				else{
					wRed = 0;
					wGreen = 0;
					wBlue = 0;
				}


				frame[xcoi + iPixelAddr + 0] = wBlue;
				frame[xcoi + iPixelAddr + 1] = wGreen;
				frame[xcoi + iPixelAddr + 2] = wRed;
			}
			iPixelAddr += stride;
		}
		/*
		 * Flush the framebuffer memory range to ensure changes are written to the
		 * actual memory, and therefore accessible by the VDMA.
		 */
		Xil_DCacheFlushRange((unsigned int) frame, DEMO_MAX_FRAME);
		break;
	case DEMO_PATTERN_2://8 intervals color bar

		for(ycoi = 0; ycoi < height; ycoi++)
		{
			for(xcoi = 0; xcoi < (width * BYTES_PIXEL); xcoi+=BYTES_PIXEL)
			{

				frame[xcoi + iPixelAddr + 0] = xcoi/BYTES_PIXEL;
				frame[xcoi + iPixelAddr + 1] = xcoi/BYTES_PIXEL;
				frame[xcoi + iPixelAddr + 2] = xcoi/BYTES_PIXEL;
			}
			iPixelAddr += stride;
		}
		/*
		 * Flush the framebuffer memory range to ensure changes are written to the
		 * actual memory, and therefore accessible by the VDMA.
		 */
		Xil_DCacheFlushRange((unsigned int) frame, DEMO_MAX_FRAME);
		break;
	case DEMO_PATTERN_3: //8 intervals color bar

		xInt = width*BYTES_PIXEL / 8; //each with width/8 pixels

		for(ycoi = 0; ycoi < height; ycoi++)
		{

			/*
			 * Just draw white in the last partial interval (when width is not divisible by 7)
			 */

			for(xcoi = 0; xcoi < (width*BYTES_PIXEL); xcoi+=BYTES_PIXEL)
			{

				if (xcoi < xInt) {                                   //White color
					wRed = 255;
					wGreen = 255;
					wBlue = 255;
				}

				else if ((xcoi >= xInt) && (xcoi < xInt*2)){         //YELLOW color
					wRed = 255;
					wGreen = 255;
					wBlue = 0;
				}
				else if ((xcoi >= xInt*2) && (xcoi < xInt*3)){        //CYAN color
					wRed = 0;
					wGreen = 255;
					wBlue = 255;
				}
				else if ((xcoi >= xInt*3) && (xcoi < xInt*4)){        //GREEN color
					wRed = 0;
					wGreen = 255;
					wBlue = 0;
				}
				else if ((xcoi >= xInt*4) && (xcoi < xInt*5)){        //MAGENTA color
					wRed = 255;
					wGreen = 0;
					wBlue = 255;
				}
				else if ((xcoi >= xInt*5) && (xcoi < xInt*6)){        //RED color
					wRed = 255;
					wGreen = 0;
					wBlue = 0;
				}
				else if ((xcoi >= xInt*6) && (xcoi < xInt*7)){        //BLUE color
					wRed = 0;
					wGreen = 0;
					wBlue = 255;
				}
				else {                                                //BLACK color
					wRed = 0;
					wGreen = 0;
					wBlue = 0;
				}

				frame[xcoi+iPixelAddr + 0] = wBlue;
				frame[xcoi+iPixelAddr + 1] = wGreen;
				frame[xcoi+iPixelAddr + 2] = wRed;
				/*
				 * This pattern is printed one vertical line at a time, so the address must be incremented
				 * by the stride instead of just 1.
				 */
			}
			iPixelAddr += stride;

		}
		/*
		 * Flush the framebuffer memory range to ensure changes are written to the
		 * actual memory, and therefore accessible by the VDMA.
		 */
		Xil_DCacheFlushRange((unsigned int) frame, DEMO_MAX_FRAME);
		break;
	default :
		xil_printf("Error: invalid pattern passed to DemoPrintTest");
	}
}
static void WriteCallBack0(void *CallbackRef, u32 Mask)    //�ж��ж�״̬�Ƿ��� FrameCount �жϣ�����ǣ��� wr_index�� 1�������� XAxiVdma_StartParking ���� park pointer �Ĵ����� WrFrmPtrRef���޸ĵ�ǰ����� Start Addresses������Ϊ wr_index[0]
{
	if (Mask & XAXIVDMA_IXR_FRMCNT_MASK)
	{
		if(WriteOneFrameEnd[0] >= 0)
				{
					return;
				}
		int hold_rd = rd_index[0];

		if(key_flag == 1)
			{
				key_flag = 2 ;
				return;
			}
		else if(key_flag == 2)
			{
				return ;
			}

		if(wr_index[0]==2)
		{
			wr_index[0]=0;
			rd_index[0]=2;
		}
		else
		{
			rd_index[0] = wr_index[0];
			wr_index[0]++;
		}
		/* Set park pointer */        //���� XAxiVdma_StartParking ���� park pointer �Ĵ����� WrFrmPtrRef���޸ĵ�ǰ����� Start Addresses
		XAxiVdma_StartParking((XAxiVdma*)CallbackRef, wr_index[0], XAXIVDMA_WRITE);
		WriteOneFrameEnd[0] = hold_rd;
	}
}

static void WriteCallBack1(void *CallbackRef, u32 Mask)    //ͬ��
{
	if (Mask & XAXIVDMA_IXR_FRMCNT_MASK)               //u32Mask��ʲô
	{

		if(WriteOneFrameEnd[1] >= 0)
				{
					return;
				}
		int hold_rd = rd_index[1];

		if(key_flag1 == 1)
					{
						key_flag1 = 2 ;
						return;
					}
		else if(key_flag1 == 2)
					{
						return ;
					}


		if(wr_index[1]==2)      //����2֡�󣬰�д֡�����ű�0
		{
			wr_index[1]=0;
			rd_index[1]=2;
		}
		else                //��ʼ׼������һ֡��ͬʱ����ǰ֡
		{
			rd_index[1] = wr_index[1];
			wr_index[1]++;
		}
		/* Set park pointer */
		XAxiVdma_StartParking((XAxiVdma*)CallbackRef, wr_index[1], XAXIVDMA_WRITE); //ʹVDMA��ͨ��פͣ�ڸ�֡�����У�Ҳ����˵дͨ���������ڶ���Դ��н����л���ʾ�����Ƿ���дͬһ֡����ʱ��ͨ��Ҳ�޷��ٶԸ�֡����д������
		WriteOneFrameEnd[1] = hold_rd;
	}
}

/*****************************************************************************/
/*
 * Call back function for write channel error interrupt
 *
 * @param	CallbackRef is the call back reference pointer
 * @param	Mask is the interrupt mask passed in from the driver
 *
 * @return	None
 *
 ******************************************************************************/
static void WriteErrorCallBack(void *CallbackRef, u32 Mask)           //�����ص�����
{

	if (Mask & XAXIVDMA_IXR_ERROR_MASK) {
		WriteError += 1;
	}
}




/*
 * Set up GPIO and enable GPIO interrupt          ����ps��led��key
 */
int GpioSetup(XScuGic *InstancePtr, u16 DeviceId, u16 IntrID, XGpioPs *GpioInstancePtr)
{
	XGpioPs_Config *GpioCfg ;
	int Status ;

	GpioCfg = XGpioPs_LookupConfig(DeviceId) ;
	Status = XGpioPs_CfgInitialize(GpioInstancePtr, GpioCfg, GpioCfg->BaseAddr) ;
	if (Status != XST_SUCCESS)
	{
		return XST_FAILURE ;
	}
	/* set MIO 50 as input */                                                    //mio50��ps��key1
	XGpioPs_SetDirectionPin(GpioInstancePtr, 50, GPIO_INPUT) ;
	/* set interrupt type */
	XGpioPs_SetIntrTypePin(GpioInstancePtr, 50, XGPIOPS_IRQ_TYPE_EDGE_RISING) ;

	/* set MIO 0 as output */                                                    //mio0��ps��led1
	XGpioPs_SetDirectionPin(&GpioInstance, 0, GPIO_OUTPUT) ;
	/* enable MIO 0 output */
	XGpioPs_SetOutputEnablePin(&GpioInstance, 0, GPIO_OUTPUT) ;
	/* set priority and trigger type */
	/*XScuGic_SetPriorityTriggerType(InstancePtr, IntrID,
			0xA0, 0x3);
	Status = XScuGic_Connect(InstancePtr, IntrID,
			(Xil_ExceptionHandler)GpioHandler,
			(void *)GpioInstancePtr) ;
     */
	//XScuGic_Enable(InstancePtr, IntrID) ;

	//XGpioPs_IntrEnablePin(GpioInstancePtr, 50) ;

	return XST_SUCCESS ;
}

int GpioSetup1(XScuGic *InstancePtr, u16 DeviceId, u16 IntrID, XGpioPs *GpioInstancePtr)
{
	XGpioPs_Config *GpioCfg ;
	int Status ;

	GpioCfg = XGpioPs_LookupConfig(DeviceId) ;
	Status = XGpioPs_CfgInitialize(GpioInstancePtr, GpioCfg, GpioCfg->BaseAddr) ;
	if (Status != XST_SUCCESS)
	{
		return XST_FAILURE ;
	}
	/* set MIO 51 as input */
	XGpioPs_SetDirectionPin(GpioInstancePtr, 51, GPIO_INPUT) ;
	/* set interrupt type */
	XGpioPs_SetIntrTypePin(GpioInstancePtr, 51, XGPIOPS_IRQ_TYPE_EDGE_RISING) ;



	/* set priority and trigger type */
	XScuGic_SetPriorityTriggerType(InstancePtr, IntrID,
			0xA0, 0x3);
	Status = XScuGic_Connect(InstancePtr, IntrID,
			(Xil_ExceptionHandler)GpioHandler,
			(void *)GpioInstancePtr) ;

	XScuGic_Enable(InstancePtr, IntrID) ;                                     //GIC����   ʲô��˼��

	XGpioPs_IntrEnablePin(GpioInstancePtr, 51) ;
	XGpioPs_IntrEnablePin(GpioInstancePtr, 50) ;

	return XST_SUCCESS ;
}
/*
 * GPIO interrupt handler
 */
void GpioHandler(void *CallbackRef)
{XGpioPs *GpioInstancePtr = (XGpioPs *)CallbackRef ;
int IntVal0 ;
int IntVal1 ;

	IntVal0 = XGpioPs_IntrGetStatusPin(GpioInstancePtr, 50) ;
	/* clear key0 interrupt */
	XGpioPs_IntrClearPin(GpioInstancePtr, 50) ;

IntVal1 = XGpioPs_IntrGetStatusPin(GpioInstancePtr, 51) ;
/* clear key1 interrupt */
XGpioPs_IntrClearPin(GpioInstancePtr, 51) ;



if (IntVal0 & KeyFlagHold)
	key_flag = 1 ;

if (IntVal1 & KeyFlagHold1)
	key_flag1 = 1 ;

}
