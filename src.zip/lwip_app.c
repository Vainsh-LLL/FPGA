#include <stdio.h>
#include "xparameters.h"
#include "netif/xadapter.h"
#include "platform.h"
#include "platform_config.h"
#if defined (__arm__) || defined(__aarch64__)
#include "xil_printf.h"
#endif
#include "xil_cache.h"
#include "display_demo.h"


//ץ��
#include "xgpio.h"
#include "ff.h"
#include "xgpiops.h"
#include "xtime_l.h"
#include "bmp.h"






#if LWIP_DHCP==1
#include "lwip/dhcp.h"
#endif

/* defined by each RAW mode application */
void print_app_header();
int start_udp8080();
int sendpic(const char *pic, int piclen, int sn);

/* missing declaration in lwIP */
void lwip_init();

#if LWIP_DHCP==1
extern volatile int dhcp_timoutcntr;
err_t dhcp_start(struct netif *netif);
#endif

extern volatile int TcpFastTmrFlag;
extern volatile int TcpSlowTmrFlag;
static struct netif server_netif;
struct netif *echo_netif;

//��Ƭ��ʾ
 u8 *DpFrames0[DISPLAY_NUM_FRAMES]; //array of pointers to the frame buffers
 u8 *DpFrames1[DISPLAY_NUM_FRAMES];

//ץ��
XGpioPs GpioInstance ;
volatile int key_flag = 0;
int KeyFlagHold = 1 ;
volatile int key_flag1 = 0;
int KeyFlagHold1 = 1 ;


static FIL fil;		/* File object */
static FATFS fatfs;
FRESULT rc;
XTime TimerStart, TimerEnd;
float elapsed_time ;
unsigned int PhotoCount = 0 ;
unsigned int PhotoCount1 = 0 ;
char PhotoName[9] ;


extern u8 *pFrames[DISPLAY_NUM_FRAMES];//

int wr_index[2];
int rd_index[2];
u8 photobuf[DEMO_MAX_FRAME] ;
unsigned char PhotoBuf[DEMO_MAX_FRAME] ;


void
print_ip(char *msg, struct ip_addr *ip) 
{
	xil_printf(msg);
	xil_printf("%d.%d.%d.%d\n\r", ip4_addr1(ip), ip4_addr2(ip), ip4_addr3(ip), ip4_addr4(ip));
}

void
print_ip_settings(struct ip_addr *ip, struct ip_addr *mask, struct ip_addr *gw)
{

	print_ip("Board IP: ", ip);
	print_ip("Netmask : ", mask);
	print_ip("Gateway : ", gw);
}

unsigned char ip_export[4];
unsigned char mac_export[6];


extern u8 *pFrames0[DISPLAY_NUM_FRAMES];
extern u8 *pFrames1[DISPLAY_NUM_FRAMES];
extern int WriteOneFrameEnd[2];
extern int frame_length_curr;
extern char targetPicHeader[8];
extern char sendchannel[2];
int lwip_loop()                                                                      //lwip�ĳ�ʼ��
{
	struct ip_addr ipaddr, netmask, gw;

	/* the mac address of the board. this should be unique per board */
	unsigned char mac_ethernet_address[] = { 0x00, 0x0a, 0x35, 0x00, 0x01, 0x02 };
	echo_netif = &server_netif;                                                         //echo_netifΪ����� netif �ṹ�����͵�ָ��
	init_platform();

#if LWIP_DHCP==1
	ipaddr.addr = 0;
	gw.addr = 0;
	netmask.addr = 0;
#else
	/* initliaze IP addresses to be used */                                           //���ð忨�� MAC ��ַ��IP ��ַ���������룬������Ϣ
	IP4_ADDR(&ipaddr,  192, 168,   1, 11);
	IP4_ADDR(&netmask, 255, 255, 255,  0);
	IP4_ADDR(&gw,      192, 168,   1,  1);
#endif	
	print_app_header();

	lwip_init();

	/* Add network interface to the netif_list, and set it as default */
	if (!xemac_add(echo_netif, &ipaddr, &netmask,&gw, mac_ethernet_address,PLATFORM_EMAC_BASEADDR)) {      //���� xemac_add �����Ѱ忨�� MAC ��ַ��IP ��ַ���������룬������Ϣ���ӵ� netif �ṹ��
		xil_printf("Error adding N/W interface\n\r");
		return -1;
	}
	netif_set_default(echo_netif);                                               //�� netif_set_default �� echo_netif ����ΪĬ������

	/* now enable interrupts */
	platform_enable_interrupts();

	/* specify that the network if is up */
	netif_set_up(echo_netif);                                                         //���� netif_set_up �򿪴�����

#if (LWIP_DHCP==1)                                                                    //����DHCP
	/* Create a new DHCP client for this interface.
	 * Note: you must call dhcp_fine_tmr() and dhcp_coarse_tmr() at
	 * the predefined regular intervals after starting the client.
	 */
	dhcp_start(echo_netif);
	dhcp_timoutcntr = 24;

	while(((echo_netif->ip_addr.addr) == 0) && (dhcp_timoutcntr > 0))
		xemacif_input(echo_netif);

	if (dhcp_timoutcntr <= 0) {
		if ((echo_netif->ip_addr.addr) == 0) {
			xil_printf("DHCP Timeout\r\n");
			xil_printf("Configuring default IP of 192.168.1.11\r\n");
			IP4_ADDR(&(echo_netif->ip_addr),  192, 168,   1, 11);
			IP4_ADDR(&(echo_netif->netmask), 255, 255, 255,  0);
			IP4_ADDR(&(echo_netif->gw),      192, 168,   1,  1);
		}
	}

	ipaddr.addr = echo_netif->ip_addr.addr;
	gw.addr = echo_netif->gw.addr;
	netmask.addr = echo_netif->netmask.addr;
#endif
	/* print ip address net mask, gateway*/
	print_ip_settings(&ipaddr, &netmask, &gw);
	memcpy(ip_export, &ipaddr, 4);
	memcpy(mac_export, &mac_ethernet_address, 6);

	/* start the application (web server, rxtest, txtest, etc..) */
	start_udp8080();                                                       //��ʼ���� udp ��Ӧ�ú������˺������������� echo.c �ļ���


	//ץ��
	/* Set PS LED off */                        //ps��led�ǵ͵�ƽ��Ч
		XGpioPs_WritePin(&GpioInstance, 0, 1) ;

		rc = f_mount(&fatfs, "0:/", 0);             //�����ļ�ϵͳ
		if (rc != FR_OK)
		{
			return 0 ;
		}


	/* receive and process packets */
	int index;
	while (1) {
		xemacif_input(echo_netif);                                         //�� xemacif_input �������ݵĽ���
		if((WriteOneFrameEnd[0] >= 0) && (sendchannel[0]) )                //�õ�����ͼ��Ľ������� WriteOneFrameEnd��������յ�ͼ����sendchannel[0]��Ч����ʼ�ְ������� sendpic ����ͼ��
		{
			targetPicHeader[4] = 2;
			index = WriteOneFrameEnd[0];
			int sn = 1;
			int cot;
			Xil_DCacheInvalidateRange((u32)pFrames0[index], frame_length_curr);
			/* Separate camera 1 frame in package */
			for(int i=0;i<frame_length_curr;i+=1440)
			{
				if((i+1440)>frame_length_curr)
				{
					cot = frame_length_curr-i;
				}
			else
				{
				cot = 1440;
				}
				sendpic((const char *)pFrames0[index]+i, cot, sn++);
			}
			WriteOneFrameEnd[0] = -1;
	}
		/* Separate camera 2 frame in package */
		if((WriteOneFrameEnd[1] >= 0) && (sendchannel[1]) )              //�жϵڶ�������ͷ�Ƿ���Ч
		{
			targetPicHeader[4] = 3;
			index = WriteOneFrameEnd[1];
			int sn = 1;
			int cot;
			Xil_DCacheInvalidateRange((u32)pFrames1[index], frame_length_curr);
			for(int i=0;i<frame_length_curr;i+=1440)
			{
				if((i+1440)>frame_length_curr)
				{
					cot = frame_length_curr-i;
				}
				else
				{
					cot = 1440;
				}
				sendpic((const char *)pFrames1[index]+i, cot, sn++);
			}
			WriteOneFrameEnd[1] = -1;
		}


		//ץ��
		if (key_flag == 2)                                                         //��key_flag=2��ʱ��ץ��
		{
			KeyFlagHold = 0;                                   //keyflaghold=0ʱ��ʾ��������
			/*
			 * increment of photo name                              ÿ������ʱ������Ƭ��+1
			 */
			PhotoCount++ ;
			sprintf(PhotoName, "R%03u.bmp", PhotoCount) ;

			/* Set PS LED on */
			XGpioPs_WritePin(&GpioInstance, 0, 0) ;                                       // ��ʼ����Ƭ����led
			printf("Successfully Take Photo, Photo Name is %s\r\n", PhotoName) ;
			printf("Write to SD Card...\r\n") ;
			/*
			 * Set timer                                                                              �����ȡ����Ƭ�Ŀ�ʼʱ��
			 */
			XTime_SetTime(0) ;                                                  //ʱ���������0
			XTime_GetTime(&TimerStart) ;                                        //��ȡ��ʼʱ��TimerStart

			Xil_DCacheInvalidateRange((unsigned int) pFrames0[(wr_index[1]+1)%3], DEMO_MAX_FRAME) ;  //��DDR��������Cache
			/*
			 * Copy frame data to photo buffer                                   ��Ƭ�ȴ浽photo buffer��
			 */
			memcpy(&photobuf, pFrames0[(wr_index[1]+1)%3],  DEMO_MAX_FRAME) ;       //�ڴ濽��������void *memcpy(void *destin, void *source, unsigned n);destin-- ָ�����ڴ洢�������ݵ�Ŀ�����飬����ǿ��ת��Ϊ void* ָ�롣source-- ָ��Ҫ���Ƶ�����Դ������ǿ��ת��Ϊ void* ָ�롣n-- Ҫ�����Ƶ��ֽ���
                                                                                //DEMO_MAX_FRAME (1920*1080*3)
			/*
			 * Clear key flag
			 */
			key_flag = 0 ;
			/*
			 * Write to SD Card                                           ��photo buffer�����Ƭ�ᵽsd��
			 */
			bmp_write(PhotoName, (char *)&BMODE_800x600/*ͷ�ļ�*/, (char *)&photobuf, DEMO_WRITE_STRIDE, &fil) ;
			/*
			 * Print Elapsed time                                                                 ��ȡ����Ƭ�Ľ���ʱ�䣬���뿪ʼʱ������õ�����ʱ��
			 */
			XTime_GetTime(&TimerEnd) ;                                         //��ȡ����ʱ��TimerEnd
			elapsed_time = ((float)(TimerEnd-TimerStart))/((float)COUNTS_PER_SECOND) ;    //��ʱ���
			printf("INFO:Elapsed time = %.2f sec\r\n", elapsed_time) ;
		}

		if (key_flag1 == 2)
			{
				KeyFlagHold1 = 0;
				/*
				 * increment of photo name
				 */
				PhotoCount1++ ;
				sprintf(PhotoName, "L%03u.bmp", PhotoCount1) ;

				/* Set PS LED on */
				XGpioPs_WritePin(&GpioInstance, 0, 0) ;
				printf("Successfully Take Photo, Photo Name is %s\r\n", PhotoName) ;
				printf("Write to SD Card...\r\n") ;
				/*
				 * Set timer
				 */
				XTime_SetTime(0) ;
				XTime_GetTime(&TimerStart) ;

				Xil_DCacheInvalidateRange((unsigned int)  pFrames1[0], DEMO_MAX_FRAME) ;
				memcpy(&photobuf,  pFrames1[0],  DEMO_MAX_FRAME) ;
				/*
				 * Clear key flag
				 */
				key_flag1 = 0 ;
				/*
				 * Write to SD Card
				 */
				bmp_write(PhotoName, (char *)&BMODE_800x600, (char *)&photobuf, DEMO_WRITE_STRIDE, &fil) ;
				/*
				 * Print Elapsed time
				 */
				XTime_GetTime(&TimerEnd) ;
				elapsed_time = ((float)(TimerEnd-TimerStart))/((float)COUNTS_PER_SECOND) ;
				printf("INFO:Elapsed time = %.2f sec\r\n", elapsed_time) ;
			}
				/* Set PS LED off */
		if(0==KeyFlagHold)
			{
				bmp_read(PhotoName,DpFrames0[0], DEMO_STRIDE,&fil);
				Xil_DCacheFlushRange((unsigned int) DpFrames0[0], DEMO_MAX_FRAME);

			}
			if(0==KeyFlagHold1)
			{
				bmp_read(PhotoName,DpFrames1[0], DEMO_STRIDE,&fil);
				Xil_DCacheFlushRange((unsigned int) DpFrames1[0], DEMO_MAX_FRAME);


			}


				XGpioPs_WritePin(&GpioInstance, 0, 1) ;
				KeyFlagHold1 = 1;
				KeyFlagHold = 1;


	}
	/* never reached */
	cleanup_platform();

	return 0;
}

